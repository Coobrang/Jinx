// Menu Mobile
const menuToggle = document.querySelector(".menu-toggle");
const mobileMenu = document.querySelector(".mobile-menu");
const closeMenu = document.querySelector(".close-menu");

menuToggle.addEventListener("click", () => {
  mobileMenu.classList.toggle("active");
});

closeMenu.addEventListener("click", () => {
  mobileMenu.classList.remove("active");
});